remove_numbers('50 km')
remove_numbers('50 km and 50m')